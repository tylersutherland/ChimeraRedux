package com.danforallseasons.objects;

public enum PhysicsState {
	STANDING, WALKING, JUMPING, FALLING
}
